extern unsigned char *ROM_DATA;
extern unsigned int ROM_DATA_LENGTH;