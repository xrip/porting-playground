# v0.5.0
- hdmi / vga / tft / tv composite versions added
- filebrowser reworked
- speed improvements


# v0.1.0
- new video driver by @AlexEkb4ever
- Huge speed optimizations
 
# v0.0.2a

Optimizations

# v0.0.2

- more games are playable. interlace and frameskip are on by default
- updated ingame menu
- ps2 keyboard support
- *.md files support

# v0.0.1

First release. Games are playable only at extreme overclocking 412Mhz. Lower overclocking profiles needs frameskip and/or interlaced mode.
All settings available through SELECT+START menu.
Sound will not be ever available. 
